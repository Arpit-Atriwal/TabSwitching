package com.example.tabswitching.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tabswitching.CallModal;
import com.example.tabswitching.R;

public class CallAdapter extends RecyclerView.Adapter<CallAdapter.ViewHolder> {
    private CallModal[] list;
    private Context context;

    public CallAdapter(CallModal[] list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.calls_list, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final CallModal myListData = list[position];
        holder.textView.setText(list[position].getDes());
        holder.profile.setImageResource(list[position].getRes());
        holder.icon.setImageResource(list[position].getPos());
    }

    @Override
    public int getItemCount() {
        return list.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView profile;
        public TextView textView;
        public ImageView icon;
        public RelativeLayout relativeLayout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.profile = itemView.findViewById(R.id.profile);
            this.textView = itemView.findViewById(R.id.textView);
            this.icon = itemView.findViewById(R.id.iconView);
            relativeLayout = itemView.findViewById(R.id.relative);
        }
    }
}