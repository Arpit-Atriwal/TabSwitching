package com.example.tabswitching;

public class CallModal {
   private int res;
   private String des;
   private int pos;

    public CallModal(int res, String des, int pos) {
        this.res = res;
        this.des = des;
        this.pos = pos;
    }
    public int getRes() {
        return res;
    }

    public void setRes(int res) {
        this.res = res;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }


}
