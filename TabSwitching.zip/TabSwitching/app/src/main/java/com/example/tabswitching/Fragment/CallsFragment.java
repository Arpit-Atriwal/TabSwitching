package com.example.tabswitching.Fragment;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tabswitching.Adapter.CallAdapter;
import com.example.tabswitching.CallModal;
import com.example.tabswitching.R;


public class CallsFragment extends Fragment {
    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLayoutManager;
    private CallAdapter mAdapter;
    CallModal[] myListData = new CallModal[]{
            new CallModal(R.drawable.p_male,"Disconnect",R.drawable.incoming),
            new CallModal(R.drawable.p_male,"Discount",R.drawable.incoming),
            new CallModal(R.drawable.p_male,"Discount",R.drawable.incoming),
            new CallModal(R.drawable.p_male,"Discount",R.drawable.incoming),
            new CallModal(R.drawable.p_male,"Discount",R.drawable.incoming),
            new CallModal(R.drawable.p_male,"Discount",R.drawable.incoming),
            new CallModal(R.drawable.p_male,"Discount",R.drawable.incoming),

    };

    public CallsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_calls, container, false);

        mRecyclerView = view.findViewById(R.id.rv1);
        mLayoutManager = new LinearLayoutManager(this.getActivity());
        Log.d("debugMode", "The application stopped after this");
        mRecyclerView.setLayoutManager(mLayoutManager);

        mAdapter = new CallAdapter(myListData, getActivity());
        mRecyclerView.setAdapter(mAdapter);
        return view;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_calls_fragment, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

}
