package com.example.tabswitching.Fragment;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tabswitching.Adapter.ListAdapter;
import com.example.tabswitching.Modal;
import com.example.tabswitching.R;


public class ChatFragment extends Fragment {
    private RecyclerView mRecyclerView;
    private LinearLayoutManager mLayoutManager;
    ListAdapter mAdapter;
     Modal[] myListData = new Modal[]{
            new Modal("Person 1 ", R.drawable.p_male),
            new Modal("Person 2 ", R.drawable.p_female),
            new Modal("Person 3 ", R.drawable.p_male),
            new Modal("Person 4 ", R.drawable.p_female),
            new Modal("Person 5 ", R.drawable.p_male),
            new Modal("Person 6 ", R.drawable.p_female),
            new Modal("Person 7 ", R.drawable.p_male),


    };
     int size = myListData.length;
    public ChatFragment() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        /*View rootView = inflater.inflate(R.layout.list_view, container, false);
        rv = rootView.findViewById(R.id.recycleView);

        ListAdapter adapter = new ListAdapter(myListData,getContext());

        rv.setHasFixedSize(true);


        rv.setLayoutManager(new LinearLayoutManager(getActivity()));


        rv.setAdapter(adapter);

        return rootView;*/
        View view = inflater.inflate(R.layout.fragment_chat, container, false);

        mRecyclerView = view.findViewById(R.id.rv);
        mLayoutManager = new LinearLayoutManager(this.getActivity());
        Log.d("debugMode", "The application stopped after this");
        mRecyclerView.setLayoutManager(mLayoutManager);

        mAdapter = new ListAdapter(myListData,getActivity());
        mRecyclerView.setAdapter(mAdapter);
        return view;

      /*  final View view = inflater.inflate(R.layout.fragment_chat, container, false);
        final FragmentActivity c = getActivity();
        final RecyclerView recyclerView = view.findViewById(R.id.rv);
        LinearLayoutManager layoutManager = new LinearLayoutManager(c);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        new Thread(new Runnable() {
            @Override
            public void run() {
                final ListAdapter adapter = new ListAdapter(myListData,c);
                c.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        recyclerView.setAdapter(adapter);
                    }
                });
            }
        }).start();

        return container;*/




    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_chat_fragment, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }
}
